﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="NamespaceDoc.cs" company="OxyPlot">
//   Copyright (c) 2014 OxyPlot contributors
// </copyright>
// <summary>
//   The OxyPlot.Avalonia namespace contains Avalonia controls and PNG export functionality based on Avalonia.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace OxyPlot.Avalonia
{
    /// <summary>
    /// The OxyPlot.Avalonia namespace contains Avalonia controls and PNG export functionality based on Avalonia.
    /// </summary>
    [System.Runtime.CompilerServices.CompilerGenerated]
    internal class NamespaceDoc
    {
    }
}