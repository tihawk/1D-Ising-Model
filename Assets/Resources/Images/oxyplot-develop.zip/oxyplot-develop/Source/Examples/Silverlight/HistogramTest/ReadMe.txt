﻿This is a port of Colin Eberhardt's test case described in
http://www.scottlogic.co.uk/blog/colin/2010/12/visiblox-visifire-dynamicdatadisplay-charting-performance-comparison/