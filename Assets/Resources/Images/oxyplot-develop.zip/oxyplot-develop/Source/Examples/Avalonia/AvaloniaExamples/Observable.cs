﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Observable.cs" company="OxyPlot">
//   Copyright (c) 2014 OxyPlot contributors
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace AvaloniaExamples
{
    public class Observable : PropertyTools.Observable
    {
    }
}