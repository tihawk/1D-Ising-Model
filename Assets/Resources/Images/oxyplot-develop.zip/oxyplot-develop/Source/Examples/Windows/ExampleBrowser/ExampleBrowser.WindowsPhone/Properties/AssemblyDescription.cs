﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ExampleBrowser.WindowsPhone")]
[assembly: AssemblyDescription("Example Browser for Windows Phone 8.1")]
